/* Polyfill service v3.25.1
 * For detailed credits and licence information see https://github.com/JakeChampion/polyfill-service.
 * 
 * Features requested: Intl.~locale.en
 *  */


/* No polyfills needed for current settings and browser */

